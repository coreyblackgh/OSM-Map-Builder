# Features
* ![0](img/0.png) → locality
* ![1](img/1.png) → beacon
* ![2](img/2.png) → subway station, subway entrance
* ![4](img/4.png) → crossing
* ![5](img/5.png) → traffic signals
* ![6](img/6.png) → dining, restaurant
* ![26](img/26.png) → hotel
* ![27](img/27.png) → camp site
* ![28](img/28.png) → shelter
* ![29](img/29.png) → museum
* ![30](img/30.png) → library
* ![31](img/31.png) → landmark
* ![32](img/32.png) → education
* ![33](img/33.png) → church, church
* ![34](img/34.png) → theatre
* ![35](img/35.png) → bar
* ![36](img/36.png) → cinema
* ![37](img/37.png) → shop, department store, grocery, general, shoping center, Convenience, clothes, house &amp; garden, do-it-yourself, organic, computers, butcher, shop
* ![42](img/42.png) → pharmacy
* ![51](img/51.png) → fuel, fuel
* ![52](img/52.png) → auto repair, auto parts
* ![53](img/53.png) → post office
* ![54](img/54.png) → bank
* ![56](img/56.png) → stop
* ![57](img/57.png) → parking
* ![58](img/58.png) → car wash
* ![59](img/59.png) → telephone
* ![60](img/60.png) → recycling
* ![61](img/61.png) → railroad station, railroad station
* ![62](img/62.png) → medicine
* ![63](img/63.png) → government institution
* ![64](img/64.png) → court
* ![65](img/65.png) → marina
* ![68](img/68.png) → picnic site
* ![69](img/69.png) → information
* ![70](img/70.png) → toilet
* ![71](img/71.png) → speed limit area
* ![72](img/72.png) → gate
* ![73](img/73.png) → bridge
* ![74](img/74.png) → building
* ![75](img/75.png) → cemetery
* ![76](img/76.png) → ford
* ![77](img/77.png) → bunker
* ![78](img/78.png) → mine
* ![79](img/79.png) → tower
* ![80](img/80.png) → wind power
* ![81](img/81.png) → windmill
* ![82](img/82.png) → waterfall
* ![83](img/83.png) → rapid
* ![84](img/84.png) → spring
* ![85](img/85.png) → wetland
* ![86](img/86.png) → egress
* ![87](img/87.png) → put in
* ![88](img/88.png) → put_in/egress
* ![89](img/89.png) → hazard
* ![90](img/90.png) → cave
* ![91](img/91.png) → cliff
* ![92](img/92.png) → barrier
* ![93](img/93.png) → fountain
* ![94](img/94.png) → bump
* ![98](img/98.png) → castle
* ![99](img/99.png) → ruins
* ![100](img/100.png) → tyre service
