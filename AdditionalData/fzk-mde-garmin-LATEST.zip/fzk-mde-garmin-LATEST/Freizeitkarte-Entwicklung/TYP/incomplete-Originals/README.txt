Die TYP Dateien in diesem Verzeichnis sind die Originaldateien von den unterschiedlichen Entwicklern. Diesen Dateien fehlen die kompletten Übersetzungen.

The TYP files in this directory are the original files from the different developers. This TYP files do not contain the complete translations.
