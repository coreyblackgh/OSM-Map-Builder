Binaries, sources and more information:
http://wiki.openstreetmap.org/wiki/Osmconvert
